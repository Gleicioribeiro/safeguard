import React from 'react';
import { Palette, Type, Check } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface CustomizationProps {
  accentColor: string;
  setAccentColor: (color: string) => void;
  fontFamily: string;
  setFontFamily: (font: string) => void;
}

const COLORS = [
  { name: 'Indigo', value: '#6366f1' },
  { name: 'Rose', value: '#f43f5e' },
  { name: 'Emerald', value: '#10b981' },
  { name: 'Amber', value: '#f59e0b' },
  { name: 'Sky', value: '#0ea5e9' },
  { name: 'Violet', value: '#8b5cf6' },
  { name: 'Orange', value: '#f97316' },
  { name: 'Slate', value: '#475569' },
];

const FONTS = [
  { name: 'Inter', value: "'Inter', sans-serif" },
  { name: 'Outfit', value: "'Outfit', sans-serif" },
  { name: 'Space Grotesk', value: "'Space Grotesk', sans-serif" },
  { name: 'JetBrains Mono', value: "'JetBrains Mono', monospace" },
];

export function Customization({ accentColor, setAccentColor, fontFamily, setFontFamily }: CustomizationProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-glass dark:bg-dark-glass backdrop-blur-md p-8 rounded-[2.5rem] border border-glass-border dark:border-dark-glass-border shadow-sm">
        <h2 className="text-3xl font-black dark:text-white mb-2">Personalização</h2>
        <p className="text-sm text-text-muted dark:text-gray-400">
          Deixe o GranaFlow com a sua cara escolhendo suas cores e fontes favoritas.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Color Selection */}
        <div className="bg-glass dark:bg-dark-glass backdrop-blur-md p-8 rounded-[2.5rem] border border-glass-border dark:border-dark-glass-border shadow-sm">
          <h3 className="text-xs font-black uppercase tracking-widest mb-8 flex items-center gap-2 dark:text-white">
            <Palette size={18} className="text-accent" />
            Cor de Destaque
          </h3>
          
          <div className="grid grid-cols-4 gap-4">
            {COLORS.map((color) => (
              <button
                key={color.value}
                onClick={() => setAccentColor(color.value)}
                className={cn(
                  "aspect-square rounded-2xl transition-all relative flex items-center justify-center group",
                  accentColor === color.value ? "ring-4 ring-accent ring-offset-4 dark:ring-offset-slate-900" : "hover:scale-110"
                )}
                style={{ backgroundColor: color.value }}
                title={color.name}
              >
                {accentColor === color.value && (
                  <Check size={20} className="text-white drop-shadow-md" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Font Selection */}
        <div className="bg-glass dark:bg-dark-glass backdrop-blur-md p-8 rounded-[2.5rem] border border-glass-border dark:border-dark-glass-border shadow-sm">
          <h3 className="text-xs font-black uppercase tracking-widest mb-8 flex items-center gap-2 dark:text-white">
            <Type size={18} className="text-accent" />
            Tipografia
          </h3>
          
          <div className="space-y-3">
            {FONTS.map((font) => (
              <button
                key={font.value}
                onClick={() => setFontFamily(font.value)}
                className={cn(
                  "w-full p-4 rounded-2xl border transition-all text-left flex items-center justify-between group",
                  fontFamily === font.value 
                    ? "bg-accent border-accent text-white shadow-lg shadow-accent/20" 
                    : "bg-white/50 dark:bg-white/5 border-glass-border dark:border-dark-glass-border text-text-main dark:text-white hover:border-accent"
                )}
                style={{ fontFamily: font.value }}
              >
                <span className="font-bold">{font.name}</span>
                {fontFamily === font.value && <Check size={18} />}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Preview Card */}
      <div className="bg-glass dark:bg-dark-glass backdrop-blur-md p-8 rounded-[2.5rem] border border-glass-border dark:border-dark-glass-border shadow-sm">
        <h3 className="text-xs font-black uppercase tracking-widest mb-6 dark:text-white">Prévia do Estilo</h3>
        <div className="p-8 rounded-3xl bg-white/50 dark:bg-white/5 border border-glass-border dark:border-dark-glass-border space-y-4">
          <h4 className="text-2xl font-black dark:text-white" style={{ fontFamily }}>O fluxo da sua grana, do seu jeito.</h4>
          <p className="text-sm text-text-muted dark:text-gray-400 leading-relaxed" style={{ fontFamily }}>
            Este é um exemplo de como os textos e cores aparecerão em todo o aplicativo. 
            A cor de destaque será usada em botões, ícones ativos e elementos de foco.
          </p>
          <div className="flex gap-3">
            <button className="px-6 py-3 bg-accent text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-lg shadow-accent/20">
              Botão de Exemplo
            </button>
            <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center text-accent">
              <Palette size={24} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
