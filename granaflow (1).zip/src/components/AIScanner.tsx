import React, { useState } from 'react';
import { Scan, Sparkles, Check, X, AlertTriangle, Loader2, Plus, Info } from 'lucide-react';
import { AIParsedTransaction, Expense, Income } from '../types';
import { parseBankNotification } from '../services/aiScannerService';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface AIScannerProps {
  onAddTransaction: (transaction: AIParsedTransaction) => void;
  onImportToFinance: (type: 'expense' | 'income', data: any) => void;
}

export function AIScanner({ onImportToFinance }: AIScannerProps) {
  const [inputText, setInputText] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [results, setResults] = useState<AIParsedTransaction[]>([]);

  const handleScan = async () => {
    if (!inputText.trim()) return;
    
    setIsScanning(true);
    try {
      const result = await parseBankNotification(inputText);
      setResults(prev => [result, ...prev]);
      setInputText('');
    } catch (error) {
      console.error(error);
    } finally {
      setIsScanning(false);
    }
  };

  const removeResult = (id: string) => {
    setResults(prev => prev.filter(r => r.id !== id));
  };

  const importTransaction = (result: AIParsedTransaction) => {
    if (result.categoria === 'credito' || result.categoria === 'debito' || result.metodo === 'credito' || result.metodo === 'debito') {
      // Import as Expense
      const expense: Partial<Expense> = {
        id: crypto.randomUUID(),
        description: result.descricao,
        value: result.valor || 0,
        category: result.metodo === 'credito' ? 'credit_one_time' : 'cash',
        date: result.data || new Date().toISOString().split('T')[0],
      };
      onImportToFinance('expense', expense);
    } else {
      // Import as Income (e.g. PIX received)
      const income: Partial<Income> = {
        id: crypto.randomUUID(),
        description: result.descricao,
        value: result.valor || 0,
        category: result.metodo === 'PIX' ? 'freelance' : 'other', // Simplified
        date: result.data || new Date().toISOString().split('T')[0],
      };
      onImportToFinance('income', income);
    }
    removeResult(result.id);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-glass dark:bg-dark-glass backdrop-blur-md p-8 rounded-[2.5rem] border border-glass-border dark:border-dark-glass-border shadow-sm">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 bg-accent/20 rounded-2xl flex items-center justify-center text-accent">
            <Scan size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-black dark:text-white">Scanner de Notificações IA</h2>
            <p className="text-sm text-text-muted dark:text-gray-400">Cole o texto de uma notificação bancária para importação automática.</p>
          </div>
        </div>

        <div className="relative">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Ex: Compra de R$ 50,00 aprovada no cartão Nubank em 23/04..."
            className="w-full h-32 bg-white/50 dark:bg-white/5 border border-glass-border dark:border-dark-glass-border rounded-2xl p-4 outline-none focus:ring-2 focus:ring-accent transition-all dark:text-white font-medium resize-none"
          />
          <button
            onClick={handleScan}
            disabled={isScanning || !inputText.trim()}
            className="absolute bottom-4 right-4 bg-accent text-white px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-accent/20 hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
          >
            {isScanning ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Sparkles size={16} />
            )}
            Escanear
          </button>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-xs font-black uppercase tracking-widest px-4 dark:text-white">Resultados da Análise</h3>
        
        <AnimatePresence initial={false}>
          {results.length > 0 ? (
            results.map((result) => (
              <motion.div
                key={result.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={cn(
                  "bg-glass dark:bg-dark-glass backdrop-blur-md p-6 rounded-3xl border shadow-sm flex items-center justify-between gap-4",
                  result.needsReview ? "border-yellow-500/50" : "border-glass-border dark:border-dark-glass-border"
                )}
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-black dark:text-white truncate">{result.descricao}</span>
                    {result.needsReview && (
                      <span className="flex items-center gap-1 text-[10px] bg-yellow-500/20 text-yellow-600 dark:text-yellow-400 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
                        <AlertTriangle size={10} /> Revisão
                      </span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1">
                    <p className="text-[10px] font-bold text-text-muted dark:text-gray-500 uppercase">
                      Valor: <span className="text-text-main dark:text-white">R$ {result.valor?.toFixed(2) || '---'}</span>
                    </p>
                    <p className="text-[10px] font-bold text-text-muted dark:text-gray-500 uppercase">
                      Data: <span className="text-text-main dark:text-white">{result.data || '---'}</span>
                    </p>
                    <p className="text-[10px] font-bold text-text-muted dark:text-gray-500 uppercase">
                      Método: <span className="text-text-main dark:text-white">{result.metodo}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => removeResult(result.id)}
                    className="p-3 text-text-muted hover:text-red-500 hover:bg-red-500/10 rounded-2xl transition-all"
                  >
                    <X size={20} />
                  </button>
                  <button
                    onClick={() => importTransaction(result)}
                    className="p-3 bg-accent/10 text-accent hover:bg-accent hover:text-white rounded-2xl transition-all flex items-center gap-2 font-black text-[10px] uppercase tracking-widest"
                  >
                    <Plus size={18} /> Importar
                  </button>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="p-12 text-center bg-glass/30 dark:bg-dark-glass/30 rounded-[2.5rem] border border-glass-border dark:border-dark-glass-border border-dashed">
              <Info size={32} className="mx-auto text-text-muted opacity-20 mb-4" />
              <p className="text-sm text-text-muted dark:text-gray-400 font-bold">Nenhum resultado para mostrar.</p>
              <p className="text-[10px] text-text-muted dark:text-gray-500 uppercase font-black tracking-widest mt-2">Cole uma notificação acima para começar</p>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
