import { GoogleGenAI, Type } from "@google/genai";
import { AIParsedTransaction } from "../types";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || "" 
});

export const parseBankNotification = async (text: string): Promise<AIParsedTransaction> => {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY is not configured.");
  }

  const prompt = `Analise a seguinte notificação de transação bancária e extraia os dados conforme as regras:
1. Extraia o valor como número decimal.
2. Extraia a data no formato ISO YYYY-MM-DD. Se não houver data, use null.
3. Identifique o método de pagamento (credito, debito, PIX, outro).
4. Mantenha a descrição original.
5. Classifique em uma categoria (credito, debito, PIX, outro).
6. Se estiver incompleto ou ambíguo, marque needsReview como true.

Notificação: "${text}"`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            valor: { type: Type.NUMBER, description: "Valor da transação" },
            data: { type: Type.STRING, description: "Data no formato YYYY-MM-DD ou null" },
            metodo: { type: Type.STRING, enum: ["credito", "debito", "PIX", "outro"] },
            descricao: { type: Type.STRING, description: "Descrição original" },
            categoria: { type: Type.STRING, enum: ["credito", "debito", "PIX", "outro"] },
            needsReview: { type: Type.BOOLEAN, description: "Verdadeiro se houver ambiguidade" }
          },
          required: ["valor", "metodo", "descricao", "categoria", "needsReview"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    
    return {
      id: crypto.randomUUID(),
      valor: result.valor ?? null,
      data: result.data ?? null,
      metodo: result.metodo || 'outro',
      descricao: result.descricao || text,
      categoria: result.categoria || 'outro',
      needsReview: result.needsReview ?? true
    };
  } catch (error) {
    console.error("Erro ao analisar notificação com IA:", error);
    return {
      id: crypto.randomUUID(),
      valor: null,
      data: null,
      metodo: 'outro',
      descricao: text,
      categoria: 'outro',
      needsReview: true
    };
  }
};
